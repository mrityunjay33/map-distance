import "./App.css";
import Map from "./Map";

function App() {
  return (
    <div className="App">
        <Map/> 
    </div>
  );
}

export default App;
